import pandas as pd
from pathlib import Path

# File to Load (Remember to Change These)
citi_data_to_load = Path("output/202001-citibike-tripdata.csv")

# Read School and Student Data File and store into Pandas DataFrames
citi_data = pd.read_csv(citi_data_to_load)

citi_data_small = citi_data.drop(["starttime", "stoptime", "end station id", \
                "end station name", "end station latitude", \
                "end station longitude", "bikeid", "birth year", "usertype", "gender"], axis=1) 

station_latitudes = citi_data_small.groupby(['start station id'])["start station latitude"].unique().tolist()
station_longitudes = citi_data_small.groupby(['start station id'])["start station longitude"].unique().tolist()
station_names = citi_data_small.groupby(['start station id'])["start station name"].unique().tolist()
station_ids = citi_data_small.groupby(['start station id'])['start station id'].unique().tolist()
ride_counts = citi_data_small.groupby(['start station id'])['start station id'].size()
minutes_per_station = citi_data_small.groupby(['start station id'])['tripduration'].sum()

year_data = pd.DataFrame({"date": 20200101, "station_id": station_ids, "station_name": station_names,\
                          "station_lat": station_latitudes, "station_long": station_longitudes, \
                          "ride_counts": ride_counts, "trip_minutes": minutes_per_station})

# df['value'] = df['value'].str[0]
year_data["station_id"] = year_data["station_id"].str[0]
year_data["station_name"] = year_data["station_name"].str[0]
year_data["station_lat"] = year_data["station_lat"].str[0]
year_data["station_long"] = year_data["station_long"].str[0]

year_data["station_id"] = year_data["station_id"].astype(int)
year_data["date"] = pd.to_datetime(year_data["date"], format='%Y%m%d')

year_data.to_csv('202001.csv')
